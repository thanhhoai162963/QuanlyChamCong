package com.example.quanlychamcong.database.Entity;

public class Enity {
}
