package com.example.quanlychamcong.database.Dao;

public interface RequestDatabase {
}
